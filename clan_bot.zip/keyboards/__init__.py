# Пакет клавиатур
from .main_menu import get_main_menu, get_back_button

__all__ = ['get_main_menu', 'get_back_button']
