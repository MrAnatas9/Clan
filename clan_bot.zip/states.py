# ========== СОСТОЯНИЯ ==========
(
    ASKING_NICKNAME, ASKING_SOURCE, SELECTING_JOBS,
    CONFIRM_REGISTRATION, TRANSFER_AMOUNT, TRANSFER_USERNAME,
    VIEWING_APPLICATIONS, REQUESTING_CREDIT_AMOUNT, REQUESTING_CREDIT_REASON,
    ADMIN_SEARCH_USER, ADMIN_MANAGE_USER, ADMIN_BAN_REASON,
    ADMIN_ADD_MONEY, CREATING_TASK_TITLE, CREATING_TASK_DESC,
    CREATING_TASK_REWARD_COINS, CREATING_TASK_REWARD_EXP, CREATING_TASK_DEADLINE,
    CASINO_BET_AMOUNT, RP_CHARACTER_NAME, RP_CHARACTER_ABILITIES,
    RP_CHARACTER_WEAKNESSES, RP_CHARACTER_ITEMS, RP_CHARACTER_BIO,
    QUOTA_WORK_DONE, QUOTA_EVENTS, QUOTA_RP_PLAYED, QUOTA_PROOF,
    VIEWING_TASKS, COMPLETING_TASK, ADMIN_RP_APPROVE_PRICE,
    VACATION_DAYS, VACATION_REASON, SUGGESTION_TEXT,
    CHANGE_NICKNAME, CHANGE_JOB_SELECTION, REQUEST_BONUS_REASON,
    PAY_CREDIT_AMOUNT, GROUP_CASINO_BET, SELL_CHARACTER_PRICE
) = range(40)

# Функции для работы с категориями (исправленные)
def get_categories():
    """Получает уникальные категории работ"""
    # Импортируем JOBS_DETAILS здесь, чтобы избежать циклического импорта
    from database import JOBS_DETAILS
    categories = set()
    for job_details in JOBS_DETAILS.values():
        category = job_details.get('category', 'Общие')
        categories.add(category)
    return sorted(categories)

def get_jobs_by_category(category):
    """Получает работы по категории"""
    from database import JOBS_DETAILS
    jobs = {}
    for job_name, job_details in JOBS_DETAILS.items():
        if job_details.get('category', 'Общие') == category:
            jobs[job_name] = job_details
    return jobs
